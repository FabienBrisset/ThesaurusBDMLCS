1. Importer dans Eclipse le projet thesaurus.zip
2. Changer les identifiants d'accés à la BDD Oracle dans ModelDB.java (NOMBDD et MOTDEPASSE)
3. Créer et initialiser la BDD dans Oracle à partir du script thesaurus.sql

